/*
 * Credits:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include "Includes/obfuscate.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "Menu.h"
#include "Toast.h"

#if defined(__aarch64__) //Compile for arm64 lib only
#include <And64InlineHook/And64InlineHook.hpp>
#else //Compile for armv7 lib only. Do not worry about greyed out highlighting code, it still works

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>

#endif

// fancy struct for patches for kittyMemory
struct My_Patches {
    // let's assume we have patches for these functions for whatever game
    // like show in miniMap boolean function
    MemoryPatch GodMode, GodMode2, SliderExample;
    // etc...
} hexPatches;

bool feature1 = false, feature2 = false, featureHookToggle = false;
int sliderValue = 1, dmgmul = 1, defmul = 1, isAmmo = 0, isreload = 0, valueFromInput, coins = 0, Levels = 0, levelup = 0;
void *instanceBtn;

// Function pointer splitted because we want to avoid crash when the il2cpp lib isn't loaded.
// If you putted getAbsoluteAddress here, the lib tries to read the address without il2cpp loaded,
// will result in a null pointer which will cause crash
// See https://guidedhacking.com/threads/android-function-pointers-hooking-template-tutorial.14771/
void (*AddMoneyExample)(void *instance, int amount);

//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint feature, jint value, jboolean boolean, jstring str) {

    const char *featureName = env->GetStringUTFChars(str, 0);

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d"), feature, featureName, value,
         boolean);

    //!!! BE CAREFUL NOT TO ACCIDENTLY REMOVE break; !!!//

    switch (feature) {
        case 1:
            feature2 = boolean;
            if (feature2) {
				isAmmo = boolean;
               MakeToast(env, obj, OBFUSCATE("武器連射[ON]"), Toast::LENGTH_SHORT);
            } else {
				isAmmo = boolean;
               MakeToast(env, obj, OBFUSCATE("武器連射[OFF]"), Toast::LENGTH_SHORT);
            }
            break;
		case 2:
            feature2 = boolean;
            if (feature2) {
				isreload = boolean;
               MakeToast(env, obj, OBFUSCATE("リロードなし[ON]"), Toast::LENGTH_SHORT);
            } else {
				isreload = boolean;
               MakeToast(env, obj, OBFUSCATE("リロードなし[OFF]"), Toast::LENGTH_SHORT);
            }
            break;
		case 3:
            feature2 = boolean;
            if (feature2) {
                hexPatches.GodMode.Modify();
				MakeToast(env, obj, OBFUSCATE("増殖[ON]"), Toast::LENGTH_SHORT);
            } else {
                hexPatches.GodMode.Restore();
				MakeToast(env, obj, OBFUSCATE("増殖[OFF]"), Toast::LENGTH_SHORT);
            }
            break;
		case 4:
            feature2 = boolean;
            if (feature2) {
                hexPatches.GodMode2.Modify();
				MakeToast(env, obj, OBFUSCATE("無敵[ON]"), Toast::LENGTH_SHORT);
            } else {
                hexPatches.GodMode2.Restore();
				MakeToast(env, obj, OBFUSCATE("無敵[OFF]"), Toast::LENGTH_SHORT);
            }
            break;
		case  5:
			coins = value;
			break;
		case  6:
			Levels = value;
			break;
		case 7:
			levelup = !levelup;
			break;
		
        
    }
}
}

// ---------- Hooking ---------- //

void(*old_GameMode_Update)(void *instance);
void GameMode_Update(void *instance) {
    if(instance != NULL) {
        if (isAmmo) { 
            *(float *) ((uint64_t) instance + 0x5C) = 0;
			} else { 
			*(float *) ((uint64_t) instance + 0x5C) = 0.5;
        }
		
	    if (isreload) { //if Toggle
            *(float *) ((uint64_t) instance + 0x68) = 0;
        } else {
            *(float *) ((uint64_t) instance + 0x68) = 2.5;
        }
    }
    old_GameMode_Update(instance);
}



void (*old_AddCoin)(void *instance, int _amount); // Your function is void, so use void, not int
void AddCoin(void *instance, int _amount)
{
    if(instance != NULL){
		if (coins) { 
		
        old_AddCoin(instance, coins); /* If you want to just modify parameters of a function, just use the old_FunctionName and change whatever parameter to whatever you like.
        Notice how I don't use return, and just call the function, that's because it's a void data type */
    }
    old_AddCoin(instance, _amount); // If instance is NULL or something else wrong, call the original function with the **Unedited** parameters
}
}

void (*old_level)(void *instance, int _amount);
void level(void *instance, int _amount) {
    if (instance != NULL)
    {
        old_level(instance, Levels);
    }
    //return the original value (this code isn't really needed if you have a toggle/switch)
    old_level(instance, _amount);
}

void (*old_Levelup)(void *instance, int _amount); // Your function is void, so use void, not int
void Levelup(void *instance, int _amount)
{
    if(instance != NULL){
		if (levelup) { 
		
        old_Levelup(instance, 100); /* If you want to just modify parameters of a function, just use the old_FunctionName and change whatever parameter to whatever you like.
        Notice how I don't use return, and just call the function, that's because it's a void data type */
    }
    old_Levelup(instance, _amount); // If instance is NULL or something else wrong, call the original function with the **Unedited** parameters
}
}

bool (*old_get_BoolExample)(void *instance);

bool get_BoolExample(void *instance) {
    if (instance != NULL && featureHookToggle) {
        return true;
    }
    return old_get_BoolExample(instance);
}

float (*old_get_FloatExample)(void *instance);

float get_FloatExample(void *instance) {
    if (instance != NULL && sliderValue > 1) {
        return (float) sliderValue;
    }
    return old_get_FloatExample(instance);
}

void (*old_Update)(void *instance);

void Update(void *instance) {
    instanceBtn = instance;
    old_Update(instance);
}

// we will run our patches in a new thread so our while loop doesn't block process main thread
// Don't forget to remove or comment out logs before you compile it.

//KittyMemory Android Example: https://github.com/MJx0/KittyMemory/blob/master/Android/test/src/main.cpp
//Note: We use OBFUSCATE_KEY for offsets which is the important part xD

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //Compile for arm64 lib only
    // New way to patch hex via KittyMemory without need to  specify len. Spaces or without spaces are fine
    hexPatches.GodMode = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x123456", '3')),
                                                    OBFUSCATE("00 00 A0 E3 1E FF 2F E1"));
    //You can also specify target lib like this
    hexPatches.GodMode2 = MemoryPatch::createWithHex("libtargetLibHere.so",
                                                     string2Offset(OBFUSCATE_KEY("0x222222", 'g')),
                                                     OBFUSCATE("00 00 A0 E3 1E FF 2F E1"));

    // Offset Hook example
    // A64HookFunction((void *) getAbsoluteAddress(targetLibName, string2Offset(OBFUSCATE_KEY("0x123456", 'l'))), (void *) get_BoolExample,
    //                (void **) &old_get_BoolExample);

    // Function pointer splitted because we want to avoid crash when the il2cpp lib isn't loaded.
    // See https://guidedhacking.com/threads/android-function-pointers-hooking-template-tutorial.14771/
    AddMoneyExample = (void(*)(void *,int))getAbsoluteAddress(targetLibName, 0x123456);

#else //Compile for armv7 lib only. Do not worry about greyed out highlighting code, it still works

    // New way to patch hex via KittyMemory without need to specify len. Spaces or without spaces are fine
    hexPatches.GodMode = MemoryPatch::createWithHex("libunity.so",
                                                    string2Offset(OBFUSCATE_KEY("0x122840", '-')),
                                                    OBFUSCATE("00 00 51 E3"));
    //You can also specify target lib like this
    hexPatches.GodMode2 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x643FE0", '-')),
                                                    OBFUSCATE("1E FF 2F E1"));
    MSHookFunction((void *)getAbsoluteAddress("libil2cpp.so", 0x86DB6C), (void *) GameMode_Update, (void **) &old_GameMode_Update);
        
	MSHookFunction((void *)getAbsoluteAddress("libil2cpp.so", 0x64143C), (void *) AddCoin, (void **) &old_AddCoin);
    MSHookFunction((void *)getAbsoluteAddress("libil2cpp.so", 0x642FE8), (void *) level, (void **) &old_level);
    MSHookFunction((void *)getAbsoluteAddress("libil2cpp.so", 0x643110), (void *) Levelup, (void **) &old_Levelup);
    
	 
    //Apply patches here if you don't use mod menu
    //hexPatches.GodMode.Modify();
    //hexPatches.GodMode2.Modify();

    // Offset Hook example
    //MSHookFunction((void *) getAbsoluteAddress(targetLibName,
    //               string2Offset(OBFUSCATE_KEY("0x123456", '?'))),
    //               (void *) get_BoolExample, (void **) &old_get_BoolExample);

    // Symbol hook example (untested). Symbol/function names can be found in IDA if the lib are not stripped. This is not for il2cpp games
    //MSHookFunction((void *) ("__SymbolNameExample"), (void *) get_BoolExample, (void **) &old_get_BoolExample);

    // Function pointer splitted because we want to avoid crash when the il2cpp lib isn't loaded.
    // See https://guidedhacking.com/threads/android-function-pointers-hooking-template-tutorial.14771/
    AddMoneyExample = (void (*)(void *, int)) getAbsoluteAddress(targetLibName, 0x123456);

    LOGI(OBFUSCATE("Done"));
#endif

    return NULL;
}

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

/*
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    return JNI_VERSION_1_6;
}
 */
